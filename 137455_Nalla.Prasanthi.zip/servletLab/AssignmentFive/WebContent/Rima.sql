CREATE TABLE Consumers(
consumer_num NUMBER(6) PRIMARY KEY,
consumer_name VARCHAR2(20) NOT NULL,
address VARCHAR2(30)
);

CREATE TABLE BillDetails(
bill_num NUMBER(6) PRIMARY KEY,
consumer_num NUMBER(6) REFERENCES Consumers(consumer_num),
cur_reading NUMBER(5,2),
unitConsumed NUMBER(5,2),
netAmount NUMBER(5,2),
bill_date DATE DEFAULT SYSDATE);

CREATE SEQUENCE seq_bill_num
START WITH 100;