package com.cg.ra.exception;

@SuppressWarnings("serial")
public class RegistrationException extends Exception {
	
	public RegistrationException(String msg) {
		super(msg);
	}
}
