package com.cg.ra.service;

import com.cg.ra.StudentBean.StudentBean;
import com.cg.ra.exception.RegistrationException;

public interface IRegisterService {
	public void add(StudentBean bean ) throws RegistrationException;
}
