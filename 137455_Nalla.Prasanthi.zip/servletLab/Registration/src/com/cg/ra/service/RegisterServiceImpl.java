package com.cg.ra.service;

import com.cg.ra.StudentBean.StudentBean;
import com.cg.ra.dao.IRegisterDao;
import com.cg.ra.dao.RegisterDaoImpl;
import com.cg.ra.exception.RegistrationException;

public class RegisterServiceImpl implements IRegisterService {
	 IRegisterDao dao=new RegisterDaoImpl();
	@Override
	public void add(StudentBean bean) throws RegistrationException {
		
		dao.add(bean);

	}

}
