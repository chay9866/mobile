package com.cg.ra.dao;

import com.cg.ra.StudentBean.StudentBean;
import com.cg.ra.exception.RegistrationException;

public interface IRegisterDao {
	
		
	public void add(StudentBean bean)throws RegistrationException;
	

  }
