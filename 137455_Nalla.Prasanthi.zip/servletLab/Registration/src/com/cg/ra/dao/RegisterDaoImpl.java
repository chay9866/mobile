package com.cg.ra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.ra.StudentBean.StudentBean;
import com.cg.ra.exception.RegistrationException;
import com.cg.ra.util.DbConnection;

public class RegisterDaoImpl implements IRegisterDao {

	@Override
	public void add(StudentBean bean) throws RegistrationException {
		try {
			Connection con=DbConnection.getConnection();
			String qry="insert into RegisterdUser values(?,?,?,?,?,?)";
			PreparedStatement pstmt=con.prepareStatement(qry);
			pstmt.setString(1, bean.getFirstName());
			pstmt.setString(2,bean.getLastName());
			pstmt.setString(3, bean.getPassWord());
			pstmt.setString(4, bean.getGender());
			pstmt.setString(5, bean.getSkillSet());
			pstmt.setString(6, bean.getCity());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			
			throw new RegistrationException("SqlException"+e.getMessage());
		}
		catch(Exception e)
		{
			throw new RegistrationException("Exception in Dao"+e.getMessage());
		}

	}

}
