package com.cg.ra.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ra.StudentBean.StudentBean;
import com.cg.ra.exception.RegistrationException;
import com.cg.ra.service.IRegisterService;
import com.cg.ra.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/Registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		IRegisterService service= new RegisterServiceImpl();
		String fName=request.getParameter("firstname");
		String lName=request.getParameter("lastname");
		String pwd=request.getParameter("password");
		String gender=request.getParameter("gender");
		String ssk=request.getParameter("skillSet" );
		String city=request.getParameter("city");
		
		StudentBean bean=new StudentBean();
		bean.setFirstName(fName);
		bean.setLastName(lName);
		bean.setPassWord(pwd);
		bean.setGender(gender);
		bean.setSkillSet(ssk);
		bean.setCity(city);
		                              
		try
		{
		service.add(bean);
		response.sendRedirect("success.html");
		}catch(RegistrationException e)
		{
			response.sendRedirect("fail.html");
		}
		
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
