package com.cg.ra.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ra.StudentBean.StudentBean;
import com.cg.ra.exception.RegistrationException;
import com.cg.ra.service.IRegisterService;
import com.cg.ra.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		IRegisterService service= new RegisterServiceImpl();
		String fName=request.getParameter("firstname");
		String lName=request.getParameter("lastname");
		String pwd=request.getParameter("pwd");
		String gender=request.getParameter("g1");
		String ssk=request.getParameter("s1" );
		String city=request.getParameter("city");
		StudentBean bean=new StudentBean();
		
		bean.setFirstName(fName);
		bean.setLastName(lName);
		bean.setPassWord(pwd);
		bean.setGender(gender);
		bean.setSkillSet(ssk);
		bean.setCity(city);
		String message;
		try
		{
		service.add(bean);
		message="Registration Done!!!!";
		}catch(RegistrationException e){
			message=e.getMessage();
		}
		request.setAttribute("message",message);
		request.setAttribute("std",bean);
		request.getRequestDispatcher("MessageServlet").forward(request,response);
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
