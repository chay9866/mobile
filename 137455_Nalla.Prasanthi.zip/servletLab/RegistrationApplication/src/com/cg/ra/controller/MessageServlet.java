package com.cg.ra.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ra.StudentBean.StudentBean;

/**
 * Servlet implementation class MessageServlet
 */
@WebServlet("/MessageServlet")
public class MessageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MessageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
	response.setContentType("text/html");
	PrintWriter out= response.getWriter();
	String message=(String) request.getAttribute("message");
	StudentBean bean=(StudentBean)request.getAttribute("std");
	out.println("<h1>"+message);
	out.println("<h2>"+bean.getFirstName());
	out.println("<h2>"+bean.getLastName());
	out.println("<h2>"+bean.getPassWord());
	out.println("<h2>"+bean.getGender());
	out.println("<h2>"+bean.getSkillSet());
	out.println("<h2>"+bean.getCity());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
