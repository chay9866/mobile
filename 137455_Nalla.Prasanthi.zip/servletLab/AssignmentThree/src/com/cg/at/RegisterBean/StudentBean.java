package com.cg.at.RegisterBean;

/*
 * @author BalaRenuka */
 
//here we are initializing all attributes

public class StudentBean {
private String firstName;
private String lastName;
private String passWord;
private String gender;
private String skillSet;
private String city;
public StudentBean() {
	super();
	// Default constructor
}
//These are the getters and setters for all attributes
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPassWord() {
	return passWord;
}
public void setPassWord(String passWord) {
	this.passWord = passWord;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getSkillSet() {
	return skillSet;
}
public void setSkillSet(String ssk) {
	this.skillSet = ssk;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}
