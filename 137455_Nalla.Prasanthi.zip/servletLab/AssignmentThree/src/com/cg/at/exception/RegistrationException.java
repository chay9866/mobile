package com.cg.at.exception;

@SuppressWarnings("serial")
public class RegistrationException extends Exception {
	
	public RegistrationException(String msg) {
		super(msg);
	}
}
