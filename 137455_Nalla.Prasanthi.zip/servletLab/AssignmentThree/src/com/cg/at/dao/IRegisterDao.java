package com.cg.at.dao;

import com.cg.at.RegisterBean.StudentBean;
import com.cg.at.exception.RegistrationException;

public interface IRegisterDao {
	
		
	public void add(StudentBean bean)throws RegistrationException;
	

  }
