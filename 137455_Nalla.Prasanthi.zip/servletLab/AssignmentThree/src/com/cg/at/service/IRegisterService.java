package com.cg.at.service;

import com.cg.at.RegisterBean.StudentBean;
import com.cg.at.exception.RegistrationException;

public interface IRegisterService {
	public void add(StudentBean bean ) throws RegistrationException;
}
