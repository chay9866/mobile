package com.cg.at.service;

import com.cg.at.RegisterBean.StudentBean;
import com.cg.at.dao.IRegisterDao;
import com.cg.at.dao.RegisterDaoImpl;
import com.cg.at.exception.RegistrationException;

public class RegisterServiceImpl implements IRegisterService {
	 IRegisterDao dao=new RegisterDaoImpl();
	@Override
	public void add(StudentBean bean) throws RegistrationException {
		
		dao.add(bean);

	}

}
