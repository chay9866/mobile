CREATE TABLE RegisteredUser
(firstname VARCHAR(20),
 lastname VARCHAR(30),
 password VARCHAR(12) UNIQUE,
 gender VARCHAR(6),
 skillset VARCHAR(40),
 city VARCHAR(12)
);