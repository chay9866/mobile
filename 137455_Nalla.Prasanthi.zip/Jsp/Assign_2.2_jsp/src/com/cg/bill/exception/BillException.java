package com.cg.bill.exception;

public class BillException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BillException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}	
}
