package com.cg.bill.dao;

import java.util.List;

import com.cg.bill.dto.Userbean;
import com.cg.bill.exception.BillException;

public interface IUserDao {
	public int addUser(Userbean bean) throws BillException;
	public Userbean getUser(String user) throws BillException;
	public List<Userbean> getAllUser()throws BillException;
}
