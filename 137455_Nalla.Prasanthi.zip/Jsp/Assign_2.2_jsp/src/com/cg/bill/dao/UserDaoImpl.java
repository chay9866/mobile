package com.cg.bill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bill.dto.Userbean;
import com.cg.bill.exception.BillException;
import com.cg.bill.util.DbConnection;

public class UserDaoImpl implements IUserDao {

	PreparedStatement preparedStatement = null;
	Connection conn = null;
	ResultSet resultSet = null;
	
	@Override
	public int addUser(Userbean bean) throws BillException {
		// TODO Auto-generated method stub
		int dataAdded = 0;
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement("INSERT INTO customer1 VALUES(?,?,?,?)");
			preparedStatement.setString(1, bean.getName());
			preparedStatement.setString(2, bean.getMobile());
			preparedStatement.setString(3, bean.getUser());
			preparedStatement.setString(4, bean.getPassword());			
			dataAdded = preparedStatement.executeUpdate();

			if (dataAdded == 1) {
				System.out.println("Successfully Added");
			}
			else
				System.out.println("Not Added");
		}
		catch (SQLException e) {
			throw new BillException("DAO ERROR:"+ e.getMessage());
		} 
		catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		} 
		finally 
		{
			try 
			{
				if (conn != null)
				{
					preparedStatement.close();
					conn.close();
				}
			} 
			catch (Exception e) {
				throw new BillException("Could not close the connection");
			}
		}
		return dataAdded;
	}

	@Override
	public List<Userbean> getAllUser() throws BillException {
		// TODO Auto-generated method stub
		List<Userbean> list = new ArrayList<Userbean>();
		Userbean dto = new Userbean();
		try 
		{
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement("select name, mobile, user1, password from customer1");
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				dto.setName(resultSet.getString(1));
				dto.setMobile(resultSet.getString(2));
				dto.setUser(resultSet.getString(3));
				dto.setPassword(resultSet.getString(4));
				list.add(dto);
				dto = new Userbean();
			}
		} 
		catch (SQLException e) {
			throw new BillException("dao/sql/ERROR:"+ e.getMessage());
		}
		catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		}
		finally 
		{
			try
			{
				if (conn != null) 
				{
					preparedStatement.close();
					conn.close();
				}
			} 
			catch (Exception e) {
				throw new BillException("Could not close the connection");
			}
		}
		return list;
	}

	@Override
	public Userbean getUser(String user) throws BillException {
		// TODO Auto-generated method stub
		Userbean dto = new Userbean();
		try {
			conn = DbConnection.getConnection();
			preparedStatement = conn.prepareStatement("select name, mobile, user1, password from customer1 where name=?");
			preparedStatement.setString(1, user);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) 
			{
				dto.setName(resultSet.getString(1));
				dto.setMobile(resultSet.getString(2));
				dto.setUser(resultSet.getString(3));
				dto.setPassword(resultSet.getString(4));
			}
		}
		catch (SQLException e) {
			throw new BillException("dao/sql/ERROR:"+ e.getMessage());
		} 
		catch (Exception e) {
			throw new BillException("ERROR:" + e.getMessage());
		}
		finally 
		{
			try
			{
				if (conn != null) 
				{
					preparedStatement.close();
					conn.close();
					resultSet.close();
				}
			} 
			catch (Exception e) 
			{
				throw new BillException("Could not close the connection");
			}
		}
		return dto;
	}
}
