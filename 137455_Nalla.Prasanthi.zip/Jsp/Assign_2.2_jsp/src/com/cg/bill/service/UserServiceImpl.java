package com.cg.bill.service; 

import java.util.List;

import com.cg.bill.dao.IUserDao;
import com.cg.bill.dao.UserDaoImpl;
import com.cg.bill.dto.Userbean;
import com.cg.bill.exception.BillException;

public class UserServiceImpl implements IUserService {

	IUserDao dao = new UserDaoImpl();
	@Override
	public int addUser(Userbean bean) throws BillException {
		// TODO Auto-generated method stub
		int result = dao.addUser(bean);
		return result;
	}
	@Override
	public List<Userbean> getAllUser() throws BillException {
		// TODO Auto-generated method stub
		List<Userbean> list = dao.getAllUser();
		return list;
	}
	@Override
	public Userbean getUser(String user) throws BillException {
		// TODO Auto-generated method stub
		Userbean bean = new Userbean();
		bean = dao.getUser(user);
		return bean;
	}
}
