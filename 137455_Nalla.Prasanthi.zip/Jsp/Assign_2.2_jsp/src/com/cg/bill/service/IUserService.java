package com.cg.bill.service;

import java.util.List;

import com.cg.bill.dto.Userbean;
import com.cg.bill.exception.BillException;

public interface IUserService {
	public int addUser(Userbean bean) throws BillException;
	public Userbean getUser(String user) throws BillException;
	public List<Userbean> getAllUser()throws BillException;
}
