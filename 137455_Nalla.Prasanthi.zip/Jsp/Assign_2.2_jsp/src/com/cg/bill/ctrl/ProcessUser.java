package com.cg.bill.ctrl;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bill.dto.Userbean;
import com.cg.bill.exception.BillException;
import com.cg.bill.service.UserServiceImpl;

@WebServlet("*.obj")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = request.getServletPath();
		String target = null;
		Userbean bean = null;
		UserServiceImpl service = new UserServiceImpl();
		HttpSession session = request.getSession(true);
		int dataAdded = 0;
		
		switch(url)
		{
			case "/index.obj":
				target = "index.jsp";
			break;
			case "/Home.obj":
				target = "Home.jsp";
			break;
			case "/Add.obj":
				bean = new Userbean();
				
				String name = request.getParameter("name");
				String mobile = request.getParameter("mobile");
				String user = request.getParameter("user");			
				String password = request.getParameter("password");
				
				bean.setName(name);
				bean.setMobile(mobile);
				bean.setUser(user);
				bean.setPassword(password);
				
				try 
				{
					dataAdded = service.addUser(bean);
				}
				catch (BillException e)
				{
					e.printStackTrace();
				}
				
				if(dataAdded != 0)
				{
					session.setAttribute("beanObj", bean);
					target = "CustomerHome.jsp";
				}
				else
				{
					target = "Error.jsp";
				}
			break;
			case "/paybill.obj":
				target = "PayBill.jsp";
			break;			
			case "/pay.obj":
				int amount = Integer.parseInt(request.getParameter("pay"));
				int total = 500 - amount;
				session.setAttribute("total", total);
				target = "submit.jsp";
			break;
			case "/viewByName.obj":
				target = "viewUser.jsp";
			break;
			case "/Search.obj":
				name = request.getParameter("userName");
				try 
				{
					bean = service.getUser(name);
				}
				catch (BillException e)
				{
					session.setAttribute("error", e.getMessage());
					target = "error.jsp";
				}
				if (bean.getName() != null) 
				{
					session.setAttribute("error", null);
					session.setAttribute("bean", bean);
					target = "viewUser.jsp";
				} 
				else
				{
					session.setAttribute("bean", null);
					session.setAttribute("error","Sorry No data Found for given ID!");
					target = "error.jsp";
				}
			break;
			case "/viewall.obj":
				List<Userbean> userList = null;
				try
				{
					userList = service.getAllUser();
				} 
				catch (BillException e) {
					target = "Error.jsp";
				}
				if (!userList.isEmpty())
				{
					session.setAttribute("userList", userList);
					target = "viewAllUser.jsp";
				} 
				else
				{
					session.setAttribute("error", "Sorry No data Found!");
					target = "viewAllUser.jsp";
				}
			break;
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}
}
