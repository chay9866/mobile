package com.cg.as.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.as.bean.User;
import com.cg.as.exception.AirSpaceException;
import com.cg.as.service.ICustomerService;
import com.cg.as.service.ICustomerServiceImp;

/**
 * Servlet implementation class ProcessUser
 */
@WebServlet("*.tsk")
public class ProcessUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProcessUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String action=request.getServletPath();
		ICustomerService servobj=new ICustomerServiceImp();
		//using switch statement//
		switch(action)
		{
		case "/addUser.tsk":
			String name=request.getParameter("name");
			String mobNo=request.getParameter("mobNo");
			String userName=request.getParameter("userName");
			String pass=request.getParameter("passOne");
			
			User us=new User();
			us.setName(name);
			us.setMobNo(mobNo);
			us.setUserName(userName);
			us.setPassword(pass);
			//using try and catch block statements//
			try
			{
				servobj.addUser(us);
				
			}catch(AirSpaceException e)
			{
				request.getSession().setAttribute("error", e.getMessage());
			}
			
			HttpSession session=request.getSession();
			session.setAttribute("UserData", us);
			RequestDispatcher reqDis=getServletContext().getRequestDispatcher("/CustomerHome.jsp");
			reqDis.forward(request, response);
			break;
			
			
		case "/generateBillId.tsk":
			try
			{
				int id=servobj.generateId();
				System.out.println(id+ "--------");
				int amount=Integer.parseInt(request.getParameter("amount"));
				int balance=750-amount;
				
				
				session=request.getSession();
				session.setAttribute("id", id);
				request.setAttribute("balance", balance);
				reqDis=getServletContext().getRequestDispatcher("/Success.jsp?id");
				reqDis.forward(request, response);
				
			}catch(AirSpaceException e)
			{
				request.getSession().setAttribute("error", e.getMessage());
			}
			
		}
	
	
	}

}
