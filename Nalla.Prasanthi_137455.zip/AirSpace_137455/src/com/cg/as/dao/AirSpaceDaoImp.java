package com.cg.as.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;









import javax.naming.NamingException;






import com.cg.as.bean.User;
import com.cg.as.exception.AirSpaceException;
import com.cg.as.util.DBUtil;

public class AirSpaceDaoImp implements IAirSpaceDao {
Connection conn=null;
PreparedStatement pst=null;
	@Override
	public void addUser(User us) throws AirSpaceException {
		try
		{
			conn=DBUtil.getConnection();
			String qry="Insert into users values(?,?,?,?)";
			pst=conn.prepareStatement(qry);
			pst.setString(1, us.getName());
			pst.setString(2, us.getMobNo());
			pst.setString(3, us.getUserName());
			pst.setString(4, us.getPassword());
			pst.executeUpdate();
		}
		catch(NamingException | SQLException e)
		{
			throw new AirSpaceException("error occured while adding user data");
		}
		finally
		{
			try{
				conn.close();
				pst.close();
			}
			catch(SQLException e)
			{
				
			}
		}
	}
	

	@Override
	public int generateId() throws AirSpaceException {
		int id=0;
		try
		{
			conn=DBUtil.getConnection();
			String query="Select seq_bills.nextval from dual";
			pst=conn.prepareStatement(query);
			ResultSet  rs=pst.executeQuery();
			if(rs.next()){
				id=rs.getInt(1);
			}
		}
			catch(NamingException | SQLException e)
			{
				throw new AirSpaceException("error occured while generating id");
			}
			finally
			{
				try{
					conn.close();
					pst.close();
				}
				catch(SQLException e)
				{
					
				}
			}
	
return id;
}
}
