package com.cg.as.dao;

import com.cg.as.bean.User;
import com.cg.as.exception.AirSpaceException;

public interface IAirSpaceDao {

	public void addUser(User us) throws AirSpaceException;
	public int generateId() throws AirSpaceException;
}
