package com.cg.as.service;

import com.cg.as.bean.User;
import com.cg.as.exception.AirSpaceException;

public interface ICustomerService {
public void addUser(User us) throws AirSpaceException;
public int generateId() throws AirSpaceException;
}
