package com.cg.as.service;

import com.cg.as.bean.User;
import com.cg.as.dao.AirSpaceDaoImp;
import com.cg.as.dao.IAirSpaceDao;
import com.cg.as.exception.AirSpaceException;

public class ICustomerServiceImp implements ICustomerService {
IAirSpaceDao daoObj=null;
	@Override
	public void addUser(User us) throws AirSpaceException {
		daoObj=new AirSpaceDaoImp();
		daoObj.addUser(us);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public int generateId() throws AirSpaceException {
		daoObj=new AirSpaceDaoImp();
		return daoObj.generateId();
		
		
		// TODO Auto-generated method stub
		
	}

}
