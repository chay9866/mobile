/**
 * 
 */

function validate()
{
var pass1=form1.passOne.value;
var pass2=form1.passTwo.value;
	if(pass1 == pass2) 
		{
		form1.action="addUser.tsk";
		}
	else
		{
		alert("Mismatch of password.. Enter agian");
		}
	
}

