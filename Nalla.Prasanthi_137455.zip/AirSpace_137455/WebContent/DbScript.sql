create table users(name varchar2(40)),
user_name varchar2(40)primarykey,
password varchar2(15),
mobile_number varchar2(12) ;                                    
create sequence_mobile_number start with 9);